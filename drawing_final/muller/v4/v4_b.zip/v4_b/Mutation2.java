import java.util.ArrayList;

public class Mutation2
{
	String pop;
	String gene;
	ArrayList<Double>freq = new ArrayList<Double>();
	boolean sig = false;
}

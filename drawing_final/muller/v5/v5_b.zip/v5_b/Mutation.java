/*
 * Hierarchical.java
 * Author: Thomas Tavolara
 */


public class Mutation
{
	String pop;
	//String chromosome;
	//String position;
	//String class_;
	//String mutation;
	String gene;
	//String aa;
	//String type;
	//String aa_change;
	//String nearest_downstream_gene;
	//String distance;
	double gen0;
	double gen140;
	double gen240;
	double gen335;
	double gen415;
	double gen505;
	double gen585; 
	double gen665;
	double gen745;
	double gen825;
	double gen910;
	double gen1000;
	boolean sig = false;
	
	public Mutation(){}
}
